

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Userinfo1
 */
@WebServlet("/Userinfo1")
public class Userinfo1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Userinfo1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String flight_id = request.getParameter("f1");
		int pass = Integer.parseInt(request.getParameter("f2"));
		String name = request.getParameter("f4");
		String sex = request.getParameter("f5");
		String date = request.getParameter("f6");
		String hno = request.getParameter("f7");
		String city = request.getParameter("f8");
		String state = request.getParameter("f9");
		int pin = Integer.parseInt(request.getParameter("f10"));
		Long mobile = Long.parseLong(request.getParameter("f11"));
		String mail = request.getParameter("f12");
		int pno = Integer.parseInt(request.getParameter("f13"));
		String pname = request.getParameter("f14");
		UserDAO c = new UserDAO();
		int i = c.addCustomer(pass, name, sex, date, hno, city, state, pin, mobile, mail,pno,pname,flight_id);
		if(i>0){
			response.sendRedirect("confirm.jsp");
		}
		doGet(request, response);
	}

}
