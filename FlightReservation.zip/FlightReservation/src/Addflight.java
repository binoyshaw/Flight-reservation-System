import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Addflight {
	static Connection con = null;
	Statement st= null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	public static Connection connect(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightdb","root","");
			//System.out.println("connection established");
			
		}
		catch(Exception e){}
		return con;
	}
	public int addFlight(String flight_id,String date,String arrival_time,String departure_time,String source,String destination,int price){
		int j=0;
		try {
		con = connect();
		PreparedStatement ps= con.prepareStatement("insert into flight_details values(?,?,?,?,?,?,?)");
		ps.setString(1,flight_id);
		ps.setString(2,date);
		ps.setString(3,arrival_time);
		ps.setString(4,departure_time);
		ps.setString(5,source);
		ps.setString(6,destination);
		ps.setInt(7,price);
		j=ps.executeUpdate();
		//System.out.println("added");
		}
		catch(Exception e){}
		return j;
	}
}
