

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String mail=request.getParameter("f1");
		String mob=request.getParameter("f2");
		long mob1=Long.parseLong(mob);
		String password=request.getParameter("f3");
		CustomerDAO c = new CustomerDAO();
		int i = c.addCustomer(mail,mob1,password);
		if(i>0){
			//out.println("Successfully done");
			//out.print("<a href ='Login.html'> <input type='button' value='Sign Out'></a>");
			HttpSession session = request.getSession(true);
			session.setAttribute("val1", mail);
			response.sendRedirect("success.html");
		}
		else{
			response.sendRedirect("error.html");
		}
		doGet(request, response);
	}

}
