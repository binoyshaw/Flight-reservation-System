import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class CustomerDAO {
	static Connection con = null;
	Statement st= null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	public static Connection connect(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightdb","root","");
			//System.out.println("connection established");	
		}
		catch(Exception e){}
		return con;
	}
	public int addCustomer(String Emails,long Mobile,String Password){
		int j=0;
		try {
		con = connect();
		PreparedStatement ps= con.prepareStatement("insert into signup values(?,?,?)");
		ps.setString(1, Emails);
		ps.setLong(2, Mobile);
		ps.setString(3,Password);
		j=ps.executeUpdate();
		}
		catch(Exception e){}
		return j;
	}
	public boolean doLogin(String emails,String password){
		int flag=0;
		try{
			con=connect();
			PreparedStatement ps1 = con.prepareStatement("select Emails , Password from signup");
			rs = ps1.executeQuery();
			while(rs.next()){
				String name1= rs.getString("Emails");
				//System.out.println("name1");
				String pass = rs.getString("Password");
				if(name1.equalsIgnoreCase(emails) && pass.equals(password)){
					flag=1;
					break;
				}
				else{
					flag=0;
				}
			}
			
			if(flag==1){
				return true;
			}
			else if(flag==0){
				return false;
			}
		
			
		}
		catch(Exception e1){
			
			System.out.println(e1);
			
		}
		return false;
	}
	public boolean doReservation(int id,String username){
		int flag=0;
		try{
			con=connect();
			PreparedStatement ps1 = con.prepareStatement("select login_id , name from user_details");
			rs = ps1.executeQuery();
			while(rs.next()){
				int id1 = Integer.parseInt(rs.getString("login_id"));
				//System.out.println("name1");
				String username1 = rs.getString("name");
				if(id1==id && username1.equalsIgnoreCase(username)){
					flag=1;
					break;
				}
				else{
					flag=0;
				}
			}
			
			if(flag==1){
				return true;
			}
			else if(flag==0){
				return false;
			}
		
			
		}
		catch(Exception e1){
			
			System.out.println(e1);
			
		}
		return false;
	}
}
