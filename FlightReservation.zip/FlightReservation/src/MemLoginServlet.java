

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MemLoginServlet
 */
@WebServlet("/MemLoginServlet")
public class MemLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		//session = request.getSession(true);
		String username = request.getParameter("t1");
		String password = request.getParameter("t2");
		//System.out.println(password);
		long pass1 = Long.parseLong(password);
		System.out.println(pass1);
		MemberDAO m = new MemberDAO();
		boolean b = m.doLogin(username, pass1);
		if(b){
			HttpSession session = request.getSession(true);
	
			session.setAttribute("key1", username);
			session.setAttribute("key2", password);
			//RequestDispatcher rd= request.getRequestDispatcher("WelcomeServlet");
			//rd.forward(request,response);
			response.sendRedirect("update.jsp");
			//out.println("Success");
		}
		else{
			response.sendRedirect("error.html");
			//out.print("Wrong credential");
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
