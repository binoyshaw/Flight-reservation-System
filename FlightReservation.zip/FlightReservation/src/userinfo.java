

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.*;
/**
 * Servlet implementation class userinfo
 */
@WebServlet("/userinfo")
public class userinfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userinfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		User user = new User();
		user.setLogin_id(Integer.parseInt(request.getParameter("f1")));
		user.setPassword(Integer.parseInt(request.getParameter("f2")));
		user.setName(request.getParameter("f4"));
		user.setSex(request.getParameter("f5"));
		user.setDate(request.getParameter("f6"));
		user.setHouseNo(Integer.parseInt(request.getParameter("f7")));
		user.setCity(request.getParameter("f8"));
		user.setState(request.getParameter("f9"));
		user.setPin(Integer.parseInt(request.getParameter("f10")));
		user.setMobile(Long.parseLong(request.getParameter("f11")));
		user.setEmail(request.getParameter("f12"));
		//user.setCity(city);	
		UserDAO c = new UserDAO();
		//int i = c.addCustomerObj(user);
		
		//int i = c.addCustomer(mail,mob1,password);

		doGet(request, response);
	}

}
