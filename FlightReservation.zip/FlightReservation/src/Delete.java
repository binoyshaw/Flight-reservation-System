

import java.io.*;
import java.sql.*;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			Connection con = null;
			ResultSet rs = null;
			Statement st = null;
			String query = null;
			String fid=null;
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			fid = request.getParameter("t1");
			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightdb","root","");
			query = "delete from flight_details where flight_id ='"+fid+"'";
			st = con.createStatement();
			int i = st.executeUpdate(query);
			System.out.println("query");
			if(i==0){
				System.out.println("Deleted");
				//out.println("<br>Row has been deleted successfully.");
				response.sendRedirect("flightdelete.html");
			}
		  }
		  catch(Exception e){}
}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
