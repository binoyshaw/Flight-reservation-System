import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class MemberDAO {

	static Connection con = null;
	Statement st= null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	public static Connection connect(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightdb","root","");
			//System.out.println("connection established");	
		}
		catch(Exception e){}
		return con;
	}
	public boolean doLogin(String name,long password){
		int flag=0;
		try{
			con=connect();
			PreparedStatement ps1 = con.prepareStatement("select name , password from admin_login");
			rs = ps1.executeQuery();
			while(rs.next()){
				String name1= rs.getString("name");
				//System.out.println("name1");
				long pass = rs.getLong("password");
				if(name1.equalsIgnoreCase(name) && pass==password){
					flag=1;
					break;
				}
				else{
					flag=0;
				}
			}
			if(flag==1){
				return true;
			}
			else if(flag==0){
				return false;
			}
		}
		catch(Exception e1){}
		return true;
	}
}
