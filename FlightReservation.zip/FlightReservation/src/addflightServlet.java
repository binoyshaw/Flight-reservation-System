

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class addflightServlet
 */
@WebServlet("/addflightServlet")
public class addflightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addflightServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter ps = response.getWriter();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String fid = request.getParameter("t1");
		String date = request.getParameter("t2");
		String at = request.getParameter("t3");
		String dt = request.getParameter("t4");
		String to = request.getParameter("t5");
		String from = request.getParameter("t6");
		int price = Integer.parseInt(request.getParameter("t7"));
		Addflight af = new Addflight();
		int i = af.addFlight(fid,date,at,dt,to,from,price);
		System.out.println("added");
		if(i>0){
			//out.print("success");
			//System.out.println("added");
			response.sendRedirect("success.html");
		}
		else{
			
		}
		doGet(request, response);
	}

}
