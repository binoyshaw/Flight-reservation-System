package bean;

public class User {
	private int login_id;
	private int password;
	private String Name;
	private String Sex;
	private String Date;
	private int HouseNo;
	private String City;
	private String State;
	private int Pin;
	private long Mobile;
	private String Email;
	
	
	
	public User() {
		super();
	}
	
	public User(int login_id, int password, String name, String sex, String date, int houseNo, String city,
			String state, int pin, long mobile, String email) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.Name = name;
		this.Sex = sex;
		this.Date = date;
		this.HouseNo = houseNo;
		this.City = city;
		this.State = state;
		this.Pin = pin;
		this.Mobile = mobile;
		this.Email = email;
	}
	public int getLogin_id() {
		return login_id;
	}
	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public int getHouseNo() {
		return HouseNo;
	}
	public void setHouseNo(int houseNo) {
		HouseNo = houseNo;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getPin() {
		return Pin;
	}
	public void setPin(int pin) {
		Pin = pin;
	}
	public long getMobile() {
		return Mobile;
	}
	public void setMobile(long mobile) {
		Mobile = mobile;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}

	@Override
	public String toString() {
		return "User []";
	}
	
	
}
