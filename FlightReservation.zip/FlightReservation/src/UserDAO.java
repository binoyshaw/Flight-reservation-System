import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

public class UserDAO {
	static Connection con = null;
	Statement st= null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	public static Connection connect(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flightdb","root","");
			//System.out.println("connection established");	
		}
		catch(Exception e){}
		return con;
	}
	/*public int addCustomerObj(User Obj){
		int j=0;
		try {
		con = connect();
		PreparedStatement ps= con.prepareStatement("insert into user_details values(?,?,?,?,?,?,?,?,?,?)");
		ps.setInt(1, Obj.getLogin_id());
		ps.setInt(2, Obj.getPassword());
		ps.setString(3, Obj.getName());
		ps.setString(4, Obj.getSex());
		ps.setString(5, Obj.getDate());
		ps.setInt(6, Obj.getHouseNo());
		ps.setString(7, Obj.getCity());
		ps.setString(8, Obj.getState());
		ps.setInt(9, Obj.getPin());
		ps.setLong(10, Obj.getMobile());
		ps.setString(11, Obj.getEmail());
		j=ps.executeUpdate();
		}
		catch(Exception e){}
		return j;
	}*/
	public int addCustomer(int password,String name,String sex,String date,String hno,String city,String state,int pin,long mobile,String mail,int pno,String pname,String flight_id){
		int j=0;
		int login_id = 0;
		try {
		con = connect();
		Statement st= null;
		ResultSet rs = null;
		//ArrayList al = null;
		String query=("select ifnull(max(login_id)+1,1001) as ID from user_details");
		st = con.createStatement();
        rs = st.executeQuery(query);
        while(rs.next()){
        	login_id = rs.getInt("ID");
        }
		PreparedStatement ps= con.prepareStatement("insert into user_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		//PreparedStatement ps= con.prepareStatement("insert into user_details values((select max(login_id)+1 from user_details),?,?,?,?,?,?,?,?,?,?,?)");
		//ps.setString(1, "select max(login_id)+1 from user_details");
		ps.setInt(1, login_id);
		ps.setInt(2, password);
		ps.setString(3, name);
		ps.setString(4, sex);
		ps.setString(5, date);
		ps.setString(6, hno);
		ps.setString(7, city);
		ps.setString(8, state);
		ps.setInt(9, pin);
		ps.setLong(10, mobile);
		ps.setString(11, mail);
		ps.setInt(12, pno);
		ps.setString(13, pname);
		ps.setString(14, flight_id);
		j=ps.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return j;
	}
}
